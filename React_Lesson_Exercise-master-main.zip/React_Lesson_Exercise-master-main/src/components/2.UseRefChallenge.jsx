/**
 * Challenge 2: useRef
 *
 * Description:
 * Create an input field with a button labeled "Focus". When the button is clicked, use useRef to focus on the input field.
 */

import { useRef } from "react";

export default function UseRefChallenge() {
 
  const Focus = () => {
    inputRef.current.focus();
  };
  const inputRef = useRef();


  return (
    <main>
      <h1>useRef Challenge</h1>
        <input type="text" ref={inputRef}/>
      
        <button onClick={Focus}> Focus </button>
    </main>
  );
}
