/**
 * Challenge 7: Final
 *
 * Description:
 * Create a form with fields for first name, last name, age, and phone number. Use state, refs, and any other React hooks of your choice to 
 * manage form data, validation, and real-time feedback. Incorporate how ever many hooks you want!
 *
 * Validation:
 * Display validation messages under each input if the input is invalid using useState and the error message should clear for the specific 
 * field if the user types in the field.
 * 
 * - All fields are required.
 * - `First name` and `last name` fields should have a max character count of 120.
 * - The `age` field must:
 *    1. Must be a number
 *    2. Have max character count of 2.
 *    3. Must be 18 or older.
 * - The `phone` field must:
 *    1. Must be a number
 *    2. Character count equals 10 (e.g., 5048073240).
 * 
 * Lastly, clear the form if validation passes and render a success message.
 */

import {useRef, useReducer} from "react";

const initialState = {
  values: {firstName: "", lastName: "", age: "", phone: ""},
  errors: {},
  success: false
}

function validate(vals) {
  const e = {}
 
  if (vals.firstName.length > 120) e.firstName = "Max 120 Characters for First Name";

  if (vals.lastName.length > 120) e.lastName = "Max 120 Characters for Last Name";
  
  if (!/^\d+$/.test(vals.age)) e.age = "Age has to be number";
  else if(vals.age.length > 2) e.age = "Max of 2 characters for Age";
  else if (Number(vals.age) < 18) e.age = "Must be 18 or older to subscribe";

  if (!/^\d+$/.test(vals.phone)) e.phone = "Phone Number has to be number";
  else if (vals.phone.length !== 10) e.phone = "Phone number has to be 10 digits";
  return e;
}

function reducer(state, action) {
  switch (action.type) {
    case "CHANGE":
      return {
        ...state,
        values: { ...state.values, [action.field]: action.value },
        errors: { ...state.errors, [action.field]: "" },
        success: false,
      };

    case "SET_ERRORS":
      return { ...state, errors: action.errors, success: false };

    case "SUBMIT_SUCCESS":
      return { ...initialState, success: true };

    default:
      return state;
  }
}



export default function FinalChallenge() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const firstRef = useRef(null);

  const handleChange = (e) =>
    dispatch({ type: "CHANGE", field: e.target.name, value: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validate(state.values);
    if (Object.keys(errors).length) {
      dispatch({ type: "SET_ERRORS", errors });
      return;
    }
    dispatch({ type: "SUBMIT_SUCCESS" });
    firstRef.current?.focus();
  };

  const { values, errors, success } = state;
  const isEmpty = !values.firstName || !values.lastName || !values.age || !values.phone;

  return (
    <main>
      <h1>Final Challenge</h1>

      <div>
        <h2>Subscribe to our Newsletter!</h2>
          <form autoComplete="off" noValidate onSubmit={handleSubmit}>
          <label>
            First Name
             <input name="firstName" ref={firstRef} value={values.firstName} onChange={handleChange} maxLength={120} type="text"/>
          </label>
           {errors.firstName && <p style={{ color: "red" }}>{errors.firstName}</p>}
           <label>
            Last Name
             <input name="lastName" value={values.lastName} onChange={handleChange} maxLength={120}/>
          </label>
           {errors.lastName && <p style={{ color: "red" }}>{errors.lastName}</p>}
           <label>
            Age
             <input name="age" value={values.age} onChange={handleChange} maxLength={2}/>
          </label>
           {errors.age && <p style={{ color: "red" }}>{errors.age}</p>}
          <label>
            Phone Number
             <input name="phone" value={values.phone} onChange={handleChange} maxLength={10}/>
          </label>
           {errors.phone && <p style={{ color: "red" }}>{errors.phone}</p>}
          

           <button type="submit" disabled={isEmpty}>Submit</button>

           {success && <p style={{ color: "green", marginTop: 20 }}> Successfully Submitted</p>}


        </form>
      </div>
    </main>
  );
}
