/**
 * Challenge 4: useReducer
 *
 * Description:
 * Create a simple to-do list with useReducer for managing the to-do state. You should be able to add and remove to-dos.
 */

import { useReducer, useRef } from "react";
import { v4 as uuidV4 } from "uuid"; // Use the uuid for a unique identifier for each todo.


  


export default function UseReducerChallenge() {

  function todoReducer(state, action) {
    switch (action.type) {
      case "ADD_TODO":
        return [...state, action.payload];
      case "REMOVE_TODO":
        return state.filter(t => t.id !== action.payload);
      default:
        return state;
    }
  }
    

    const inputRef = useRef();
    const [todos, dispatch] = useReducer(todoReducer, []);

    function handleAdd() {
      const text = inputRef.current?.value?.trim()
      if (!text) return;
      const newTodo = { id: uuidV4(), text }
      dispatch({type: "ADD_TODO", payload: newTodo})
      inputRef.current.value = ""
    }


    function handleRemove(id) {
      dispatch({type: "REMOVE_TODO", payload: id})
    }

    return (
      <main>
        <h1>useReducer Challenge</h1>
        <div>
          <h2>To-do</h2>
          <input ref={inputRef} placeholder="Add a new to-do" />
          <button onClick={handleAdd}>Add</button>

          <ul style={{listStyleType: "none"}}>{
              todos.map(todo => (
                <li key={todo.id} style={{textAlign: "center"}}>
                  {todo.text} <button onClick={() => handleRemove(todo.id)} style={{marginLeft: "20px", marginBottom: "15px"}}> Remove </button>
                </li>
              ))
            }</ul>
        </div>
      </main>
    );
}